function output = dispp(image1,image2)
colormap(gray)
subplot(1,2,1), imagesc(image1)
axis off
subplot(1,2,2), imagesc(image2)
axis off
