syms t f w
disp('let us start with a continuous FT')
p=0.5*sin(t)+0.25*sin(2*t)+0.35*sin(3*t)+0.25*sin(4*t);
TW=36;  %base period is 6, so TW=18 = 3*T
wR = 1/(0.5*(TW/2))*rectangularPulse(-TW/2,TW/2,t);
wHAN=(.5+0.5*cos(pi*t/(TW/2)))*wR; %scaling is by area
FwHAN=fourier(wHAN);
magwHAN=sqrt(real(FwHAN)*real(FwHAN)+imag(FwHAN)*imag(FwHAN));
HAN_windowed_p=p*wHAN;
subplot(1,2,1)
fplot(HAN_windowed_p, [-12 12])
title('Original signal')
F_HAN_windowed_p=fourier(HAN_windowed_p);
magF_HAN_windowed_p=sqrt(real(F_HAN_windowed_p)*real(F_HAN_windowed_p)+imag(F_HAN_windowed_p)*imag(F_HAN_windowed_p));
subplot(1,2,2)
fplot(magF_HAN_windowed_p, [-12 12])
title('Continuous FT of signal')
pause

disp('Hard days night')
hard=audioread('hard_chord_long.wav');
hard_for_centred=centre1D(hard);
subplot(1,2,1)
plot(hard)
title('Hard days night opening chord')
F_hard=fft(hard_for_centred); %we'll use fft (which comes later) as DFT takes donkeys!
subplot(1,2,2)
plot(abs(F_hard))
title('Fourier transform of Hard days night')
pause

disp('now FT of pulse')
T=0.5;
p=rectangularPulse(-T/2,T/2,t);
Fp=fourier(p);
subplot(1,2,1)
fplot(p, [-1.5,1.5])
title('Pulse')
mag=real(Fp)*real(Fp)+imag(Fp)*imag(Fp);
subplot(1,2,2)
fplot(mag, [-12*pi,12*pi])
title('Fourier transform of pulse')


