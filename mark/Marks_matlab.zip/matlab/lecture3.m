pic=imread('target.png'); %3D target
pic=double(pic(:,:,1));
pic2=imread('cloth.png'); %image of cloth
pic2=double(pic2(:,:,1));

Fpic=fft2(centre(pic)); %centre it
colormap(gray)

disp('2D DFT of image')
subplot(1,2,1)
imagesc(pic)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(log(abs(Fpic)))
axis off
title('Magnitude of 2-D discrete Fourier transform')
pause

disp('Magnitude and phase of DFT of image')
subplot(1,2,1)
imagesc(log(abs(Fpic)))
axis off
title('Magnitude of DFT transform')
colormap(gray)
subplot(1,2,2)
imagesc(angle(Fpic))
axis off
title('Phase of DFT transform')
pause

disp('Rotating DFT, rotate image first')
pic3=imread('cloth-rot.png'); %image of cloth rotated
pic3=double(pic3(:,:,1));
subplot(1,2,1)
imagesc(pic2) %rotate the image
axis off
title('New image')
colormap(gray)
subplot(1,2,2)
imagesc(pic3)
axis off
title('Rotated new image')
pause

disp('transform rotates with image')
subplot(1,2,1)
imagesc(log(abs(fft2(centre(pic2))))) %rotate the image
axis off
title('Magnitude of transform of original image')
colormap(gray)
subplot(1,2,2)
imagesc(transpose(log(abs(fft2(centre(pic3))))))
axis off
title('Magnitude of transform of rotated image')
pause

disp('shift the image')
subplot(1,2,1)
imagesc(pic2)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(shift(pic2,650,670))
axis off
title('Shifted image')
pause

disp('What happends to transform?')
subplot(1,2,1)
imagesc(log(abs(fft2(centre(pic2)))))
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(log(abs(fft2(centre(shift(pic2,650,670))))))
axis off
title('Shifted image')
