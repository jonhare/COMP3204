pic=imread('U2.png'); %3D target
pic=double(pic(:,:,1));
pic2=imread('cloth.png'); %image of cloth
pic2=double(pic2(:,:,1));

disp('Alons y Monsieur Canny')
a=template_convolve(eye,Gaussian_template(5,0.7));

peakySobel=non_max_supp(Sobel_edges(a));
thresholded_peaks = hyst_thr(peakySobel,50,5);
imagesc(thresholded_peaks);
disp('Try changing the upper and lower thresholds to see the detection of features and noise, respectively')
pause

disp('Let us see some edge detection')
subplot(1,2,1)
imagesc(pic2)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(log(basic_difference(pic2)))
axis off
title('After 2*2 basic edge detection')
disp('Plotting as log')
pause

disp('Let us see the components')
subplot(1,2,1)
imagesc(log(horizontal_difference(pic2)))
axis off
title('Horizontal operator')
colormap(gray)
subplot(1,2,2)
imagesc(log(vertical_difference(pic2)))
axis off
title('Vertical operator')
pause

disp('Let us see comparison with Sobel')
subplot(1,2,1)
imagesc(log(basic_difference(pic2)))
axis off
title('Basic 2*2')
colormap(gray)
subplot(1,2,2)
imagesc(log(Sobel(pic2)))
axis off
title('Sobel')
disp('Edges are cleaner, noise is less')
pause

disp('Let us see comparison with generalised Sobel')
subplot(1,2,1)
imagesc((Sobel(pic)))
axis off
title('Basic 3*3')
colormap(gray)
subplot(1,2,2)
imagesc((generalised_Sobel(pic,9)))
axis off
title('Generalised Sobel, 9*9')
disp('He should have seen that edge!!')

