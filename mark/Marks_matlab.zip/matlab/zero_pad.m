function temp_image = zero_pad(image, template)
%makes an dim*dim averaging template
%
%  Usage: [template] = av_template(picture)
%
%  Parameters: image      - array of points 
%              template = size*size

%get dimensions
[rows,cols]=size(image); 
temp_image(1:rows,1:cols)=0; %empty image
[rows,cols]=size(template);
temp_image(1:rows,1:cols)=template; %add template
end