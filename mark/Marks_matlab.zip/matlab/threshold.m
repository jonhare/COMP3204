function thresholded = threshold(image,level)
%Set points below level to 1.0, others to black
%
%  Usage: [new image] = threshold(image)
%
%  Parameters: image      - array of points
%              threshold  - brightness level
%

%get dimensions
[rows,cols]=size(image); 

%set points to white if above threshold level, to black otherwise
for x = 1:cols %address all columns
  for y = 1:rows %address all rows
    if image(y,x)<level thresholded(y,x)=0; %Eq 3.11
                   else thresholded(y,x)=1;
    end
  end
end
