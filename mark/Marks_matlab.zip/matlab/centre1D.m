function centred = centre1D(points)

% Prepares point for FT windowed at centre 
N=length(points);
centred(1:N)=0; %declare storage
for x=1:N
    centred(x)=points(x)*(-1)^x; %Equation 3.12
end

