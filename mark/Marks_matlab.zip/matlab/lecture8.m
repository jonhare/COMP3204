pic=imread('U2.png'); %3D target
pic=double(pic(:,:,1));
pic2=imread('cloth.png'); %image of cloth
pic2=double(pic2(:,:,1));
eye=imread('eye_orig.jpg');
eye=double(eye(:,:,1));
colormap(gray)

eye=imread('eye','jpg');
imagesc(eye(:,:,1))
title('Original image')
axis off
disp ('Hit return to continue')
pause
disp ('And here is its edge detected version.')
eye=double(eye(:,:,1));
sob_eye=Sobel(eye);
imagesc(sob_eye(:,:,1))
title('After edge detection')
axis off
disp ('Hit return to continue')
pause

%define circle template
xcentre=60;
ycentre=50;
radius=48;
b=draw_full_circle(eye,xcentre,ycentre,radius);
c=b(ycentre-radius:ycentre+radius,xcentre-radius:xcentre+radius);

disp ('First, we shall do it by template matching')
d=template_match(sob_eye(:,:,1),c);
imagesc(d)
title('Result of template matching')
axis off
disp ('That is pretty good, eh!')
disp ('Hit return to continue')
pause

disp ('Now we shall do template matching by Fourier')
e=template_match_Fourier(sob_eye(:,:,1),c);
imagesc(e)
title('After Fourier template matching')
axis off
disp ('That is just the same, and it was quicker.')
disp ('Hit return to continue')
pause

disp ('Now we find lines by the Hough transform, so wait...')
lizard=imread('lizardverysmall.png');
lizard=double(lizard(:,:,1));
newlizard=line_hough(lizard);
%that line looks good eh!
%let's have a look
edges=Sobel(lizard);
subplot(1,2,1), imagesc(edges(:,:,1))
axis off
plotedit on, title ('Edge detected version'), plotedit off
subplot(1,2,2), imagesc(newlizard)
axis off
plotedit on, title ('Detected line'), plotedit off
pause


disp ('Now we shall do it by the Hough transform for circles, so wait...')
a=circle_hough(sob_eye(:,:,1),20);
imagesc(a);
disp ('That is the centre.')
disp ('Hit return to continue')
pause
