pic=imread('target.png'); %3D target
pic=double(pic(:,:,1));
pic2=imread('cloth.png'); %image of cloth
pic2=double(pic2(:,:,1));

disp('Let us see some averaging')
subplot(1,2,1)
imagesc(pic)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(template_convolve(pic,ave_template(9)))
axis off
title('After 9*9 averaging image')
pause

disp('Let us get rid of some noise')
subplot(1,2,1)
imagesc(add_Gaussian_noise(pic,20))
axis off
title('Noisy image')
colormap(gray)
subplot(1,2,2)
imagesc(template_convolve(add_Gaussian_noise(pic,20),ave_template(9)))
axis off
title('After 9*9 averaging')
pause

disp('Let us see some bigger operators')
subplot(1,2,1)
imagesc(template_convolve(add_Gaussian_noise(pic,20),ave_template(15)))
axis off
title('After 15*15 averaging')
colormap(gray)
subplot(1,2,2)
imagesc(template_convolve(add_Gaussian_noise(pic,20),ave_template(21)))
axis off
title('After 21*21 averaging')
disp('They took some time eh, let us see how long')

% That took a bit of time, let us see how long')
tic  %note the axes appear
imagesc(template_convolve(add_Gaussian_noise(pic,20),ave_template(21)))
imagesc(template_convolve(add_Gaussian_noise(pic,20),ave_template(23)))
toc
pause

disp('So we shall use Fourier')
subplot(1,2,1)
tic
template_image=zero_pad(pic,ave_template(21));
averaged=ifft2(fft2(pic).*fft2(template_image));
imagesc(averaged)
axis off
title('After 21*21 Fourier averaging')  %Notice no border!!
colormap(gray)
subplot(1,2,2)
template_image=zero_pad(pic,ave_template(23));
averaged=ifft2(fft2(pic).*fft2(template_image));
imagesc(averaged)
axis off
title('After 23*23 Fourier averaging')
disp('The time is now')
toc  %mention speed
pause

disp('Compare direct with Gaussian')
subplot(1,2,1)
template_image=zero_pad(pic2,ave_template(21));
averaged=ifft2(fft2(pic2).*fft2(template_image));
imagesc(averaged)
axis off
title('After 21*21 Fourier direct averaging')
colormap(gray)
subplot(1,2,2)
template_image=zero_pad(pic2,Gaussian_template(23,5));
averaged=ifft2(fft2(pic2).*fft2(template_image));
imagesc(averaged)
axis off
title('After 21*21 Fourier Gaussian averaging')
pause

disp('Do some median filtering')
subplot(1,2,1)
imagesc(add_salt_and_pepper(pic2,.1))
axis off
title('With salt and pepper')
colormap(gray)
subplot(1,2,2)
imagesc(median(add_salt_and_pepper(pic2,.1),5))
axis off
title('After 5*5 median filter')
pause

disp('Now for a modern operator, non local means')
subplot(1,2,1)
imagesc(add_Gaussian_noise(pic,40))
axis off
title('Noisy image')
colormap(gray)
subplot(1,2,2)
imagesc(non_local_means(add_Gaussian_noise(pic,40),7,15,2)) 
axis off %this was the first set of parameters I chose!!!!
title('With more noise and after non-local means operator') %bloody smart eh!!
