pic=imread('U2.png'); %3D target
pic=double(pic(:,:,1));
pic2=imread('cloth.png'); %image of cloth
pic2=double(pic2(:,:,1));
eye=imread('eye_orig.jpg');
eye=double(eye(:,:,1));
colormap(gray)

disp('Alons y Monsieur Canny')
a=template_convolve(eye,Gaussian_template(5,0.7));
subplot(1,2,1)
imagesc(eye)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(a)
axis off
title('After Gaussian smoothing')
pause

peakySobel=non_max_supp(Sobel_edges(a));
subplot(1,2,1)
imagesc(eye)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
image(peakySobel)
axis off
title('After nonmax suppression')
pause

thresholded_peaks = hyst_thr(peakySobel,50,5);
subplot(1,2,1)
imagesc(eye)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
image(thresholded_peaks)
axis off
title('After hysteresis thresholding')
disp('Try changing the upper and lower thresholds to see the detection of features and noise, respectively')
pause

disp('We shall compare Canny with Sobel')
eye=imread('lizardverysmall.png');
eye=double(eye(:,:,1));
colormap(gray);
imagesc(eye)
a=template_convolve(eye,Gaussian_template(5,.7));
imagesc(a)
peakySobel=non_max_supp(Sobel_edges(a));
peakySobel=normalise(peakySobel);
thresholded_peaks = hyst_thr(peakySobel,40,5);
thresholded_peaks=threshold(thresholded_peaks,200);
b=Sobel(a);
c=threshold(b(:,:,1),110);
subplot(1,2,1), imagesc(thresholded_peaks);
plotedit on, title ('Result via Canny'), plotedit off
subplot(1,2,2), imagesc(c);
plotedit on, title ('Result via Sobel'), plotedit off
pause

disp('Step up Marr Hildreth')
a=template_convolve(eye,LoG_template(19,3));
b=zero_cross(a);
subplot(1,2,1)
imagesc(eye)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(b)
title('After Marr Hildreth')
axis off
disp('Try different values of the template size and variance. Note that the contours are connected.')
disp ('When you are ready to move on, press RETURN')
pause;

disp('Give context aware saliency a go!')
eye=imread('lizardverysmall_colour.png');
disp('Note that this takes a while...')
cas = context_aware_saliency(eye,7,10);
subplot(1,2,1)
imagesc(eye)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(cas)
title('After context aware saliency')
axis off
disp('Try different values for patch_size and searchsize (but not big ones unless you are off for dinner)')

