pic=imread('target.png'); %3D target
pic=double(pic(:,:,1));
pic2=imread('cloth.png'); %image of cloth
pic2=double(pic2(:,:,1));

disp('Let us see a histogram')
colormap(gray)
subplot(1,2,1)
imagesc(pic)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
plot(histogram(pic));
plotedit on, title ('Histogram'), xlabel ('Brightness'),ylabel ('Number'),
title('Histogram of image')
pause

disp('Normalise an image')
subplot(1,2,1)
image(pic)
axis off
title('Original image')
colormap(gray)
subplot(1,2,2)
imagesc(pic)
axis off
title('Normalised image')
pause

disp('Normalise an image and comare with equalise')
pic=uint8(pic2);
subplot(1,2,1)
imagesc(pic2)
axis off
title('Normalised image')
colormap(gray)
subplot(1,2,2)
imagesc(equalise(pic2))
axis off
title('Equalised image')
pause

disp('Threshold an image')
subplot(1,2,1)
imagesc(pic2)
axis off
title('Image')
colormap(gray)
subplot(1,2,2)
imagesc(threshold(pic2,240))
axis off
title('Image, thresholded at 240')
